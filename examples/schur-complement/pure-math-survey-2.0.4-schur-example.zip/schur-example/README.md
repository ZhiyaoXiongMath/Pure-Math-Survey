# Schur-complement workflow example - Pure Math Survey 2.0.4

The nine-node knowledge project supplies a minimal survey (two pages) and a
lecture (three pages) from one immutable snapshot. The mathematical manuscripts
and canonical statements are preserved. Both outputs were prepared, built, rendered and reread with version 2.0.3;
version 2.0.4 revalidates the unchanged mathematical artifacts after publication
cleanup. Every supplied PDF page was inspected during that cleanup.
The review mode is author_reread. Original source-reading records retain their
actual dates and scope; no new source search or independent review is claimed.

Use the installed Pure Math Survey 2.0.4:

```sh
python PATH_TO_SKILL/scripts/survey.py kb validate project --json
python PATH_TO_SKILL/scripts/survey.py output validate project --output schur-minimal --stage release --json
python PATH_TO_SKILL/scripts/survey.py output validate project --output schur-lecture --stage release --json
```

The project includes the knowledge, source-reading notes, selected snapshot,
plans, exact fragments, manuscripts and the evidence required by those commands.
There is no bundled skill installation, development test exercise or previous
release archive. FILES-SHA256.txt identifies every distributed member.

PDF builds require pdfLaTeX, BibTeX and Poppler. To rebuild a copy, run
`survey.py output build project --output schur-minimal` (or schur-lecture).
New PDF bytes need fresh rendering and page inspection before accepting new
visual evidence. The controlling source PDF is not redistributed.

## Public distribution hygiene

This copy omits archived build history, TeX auxiliary files and raw command logs.
Build and render reports retain their original results, input hashes, PDF hashes
and tool versions, while machine-specific executable locations are replaced by
basenames. The reports explicitly record this redaction; they do not claim a new
build. The mathematical manuscripts, knowledge, snapshots, source-reading
records, PDFs and page images are unchanged. Original author-review records are
retained unchanged; a separate visual review binds the redacted reports after
all five supplied page images were inspected. No new mathematical source reading
or independent review is claimed. Rebuilding creates new local logs and history
that should remain private until separately checked for publication.
