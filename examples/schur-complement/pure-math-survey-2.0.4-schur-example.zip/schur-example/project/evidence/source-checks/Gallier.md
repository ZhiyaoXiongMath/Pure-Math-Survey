# Actual source reading

Read the author-hosted original PDF on 2026-09-28. Its first page dates it
August 24, 2019; do not inherit the December 2010 date from search metadata.
Private downloaded PDF: 170418 bytes, SHA-256
74350eb0b885691107bcfc998148e88664b8285428a19b128b0e449e06a0bdea.
This fingerprint documents that download; it is not a binding to a bundled file.
No original-source text or PDF is redistributed in this example.

Supporting reading: Section 1, pages 1--2, block elimination; Section 2,
pages 3--4, Propositions 2.1--2.2 and the congruence proof. The source's lower
right block C is denoted D locally; no mathematical hypothesis changes.
All matrices are finite and real, diagonal blocks symmetric, and inverses
require invertible pivots. Proposition 2.2(1) is the positive definite criterion.

The word "similar" preceding Proposition 2.1 does not describe the displayed
factorization in its ordinary matrix-theoretic sense. It is congruence.
Our proof checks the invertible quadratic-form substitution directly.

Omission challenge: read Theorem 4.3 and adjacent discussion on pages 12--13.
The singular criterion has the additional condition (I-AA^dagger)B=0.
Its full proof and the intervening pseudoinverse development were not reread;
that theorem remains unassessed context and is not a proof input.
Only author self-review is claimed, not independent verification.
