# Scope

For finite real symmetric block matrices, determine exactly when positive
definiteness can be checked using the leading block and its Schur complement.
Explain the invertible change of variables, compute a scalar-block example,
and distinguish strict positivity, semidefiniteness and singular pivots.
Give a minimal reading and a lecture from the same reviewed knowledge snapshot.
Prerequisites: real vector spaces, matrix multiplication and determinants.
Exclude numerical conditioning, algorithms, operators on infinite dimensional
spaces, complex Hermitian generalizations and a proof of the general
pseudoinverse criterion. Retain that neighboring criterion as unassessed context.
