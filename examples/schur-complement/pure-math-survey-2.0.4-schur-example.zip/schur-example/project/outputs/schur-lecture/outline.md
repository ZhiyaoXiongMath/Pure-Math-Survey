# Writing task

Develop prerequisite definitions and the promised proof steps; state imported inputs accurately.

Reader goals:
- Apply the precise positive-definite criterion without losing invertibility or strictness.
- Recover the elimination calculation and diagnose the stated counterexamples.

Suggested nodes (editable pedagogical order):
- [[N-setting]]
- [[N-boundary]]
- [[N-congruence]]
- [[N-criterion]]
- [[N-factorization]]
- [[N-determinant]]
- [[N-question]]
- [[N-scalar]]

No semantic or visual review has been performed by this preparation command.
