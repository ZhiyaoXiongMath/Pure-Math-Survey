# Writing task

Put the usable question and exact answer early; retain the key calculation and decisive boundary.

Reader goals:
- Apply the precise positive-definite criterion without losing invertibility or strictness.
- Recover the elimination calculation and diagnose the stated counterexamples.

Suggested nodes (editable pedagogical order):
- [[N-boundary]]
- [[N-congruence]]
- [[N-criterion]]
- [[N-determinant]]
- [[N-factorization]]
- [[N-scalar]]
- [[N-setting]]

No semantic or visual review has been performed by this preparation command.
