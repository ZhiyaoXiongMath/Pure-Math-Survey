---
{
  "schema_version": "2.0.0",
  "id": "N-generalized",
  "kind": "frontier",
  "title": "Unassessed neighboring singular-pivot theorem",
  "facets": [
    "boundaries"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "unassessed",
  "origin": "local_derivation",
  "sources": [],
  "links": []
}
---

# Unassessed neighboring singular-pivot theorem

Gallier (2019), Theorem 4.3, page 12, treats positive semidefinite matrices using a pseudoinverse and a range condition. Its full proof is outside this reading task and has not been reviewed here. This is unassessed known neighboring material, not an assertion that the problem is open.
