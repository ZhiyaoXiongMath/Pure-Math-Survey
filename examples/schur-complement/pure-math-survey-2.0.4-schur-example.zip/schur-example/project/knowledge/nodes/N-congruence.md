---
{
  "schema_version": "2.0.0",
  "id": "N-congruence",
  "kind": "result",
  "title": "Invertible changes of variables",
  "facets": [
    "foundations",
    "methods"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": [
    {
      "target": "N-setting",
      "relation": "uses_definition"
    }
  ]
}
---


# Invertible changes of variables

## Canonical statement

```latex
For every real symmetric $k\times k$ matrix $H$ and every invertible real $k\times k$ matrix $P$, one has $H\succ0$ if and only if $P^\top HP\succ0$.
```

## Explanation

For every z, z^T(P^THP)z=(Pz)^TH(Pz). Since P is a bijection and maps nonzero vectors to nonzero vectors, strict positivity is equivalent in the two coordinates. This argument does not assert equality of eigenvalues.
