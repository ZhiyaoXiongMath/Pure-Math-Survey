---
{
  "schema_version": "2.0.0",
  "id": "N-question",
  "kind": "question",
  "title": "Which block data determine positive definiteness?",
  "facets": [
    "foundations",
    "results"
  ],
  "question_ids": [],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": []
}
---


# Which block data determine positive definiteness?

For real symmetric M with an invertible leading block, characterize M>0 by lower-dimensional conditions. Which exact invertibility and strictness hypotheses are needed, and what computation proves both directions?
