---
{
  "schema_version": "2.0.0",
  "id": "N-criterion",
  "kind": "result",
  "title": "The positive definite Schur criterion",
  "facets": [
    "results",
    "foundations"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "primary_source",
  "sources": [
    {
      "source_id": "S-Gallier",
      "locator": "Section 2, Proposition 2.2(1), printed page 4 (2019 version)",
      "role": "support"
    }
  ],
  "links": [
    {
      "target": "N-setting",
      "relation": "uses_definition"
    },
    {
      "target": "N-factorization",
      "relation": "explained_by"
    }
  ]
}
---


# The positive definite Schur criterion

## Canonical statement

```latex
Let $m,n\geq1$. Let $A\in\mathbb R^{m\times m}$ and $D\in\mathbb R^{n\times n}$ be symmetric, let $B\in\mathbb R^{m\times n}$, and assume that $A$ is invertible. Then\[\begin{pmatrix}A&B\\B^\top&D\end{pmatrix}\succ0\quad\Longleftrightarrow\quad A\succ0\ \text{and}\ D-B^\top A^{-1}B\succ0.\]
```

## Explanation

Necessity: restrict M to vectors (x,0) to obtain A>0. For nonzero y choose x=-A^{-1}By; positivity gives y^TSy>0. Sufficiency: the completed square is a sum of positive quadratic forms; for (x,y) nonzero, either y is nonzero or y=0 and x is nonzero. The assumed inverse is legitimate. This reproduces the supporting proposition with D in place of the source C.
