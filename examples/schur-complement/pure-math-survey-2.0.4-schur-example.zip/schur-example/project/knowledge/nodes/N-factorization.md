---
{
  "schema_version": "2.0.0",
  "id": "N-factorization",
  "kind": "mechanism",
  "title": "Eliminate the mixed term",
  "facets": [
    "methods",
    "results"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": [
    {
      "target": "N-setting",
      "relation": "uses_definition"
    },
    {
      "target": "N-congruence",
      "relation": "proof_input"
    }
  ]
}
---


# Eliminate the mixed term

## Canonical statement

```latex
For symmetric $A\in\mathbb R^{m\times m}$ and $D\in\mathbb R^{n\times n}$, $B\in\mathbb R^{m\times n}$, and invertible $A$, set $M=\begin{pmatrix}A&B\\B^\top&D\end{pmatrix}$, $S=D-B^\top A^{-1}B$ and $P=\begin{pmatrix}I_m&-A^{-1}B\\0&I_n\end{pmatrix}$. Then $P$ is invertible and $P^\top MP=\operatorname{diag}(A,S)$.
```

## Explanation

Assume A is invertible. Set P=[[I,-A^{-1}B],[0,I]]. It is invertible, with the opposite sign in its off-diagonal block for P^{-1}. Direct multiplication gives MP=[[A,0],[B^T,S]], and then P^TMP=diag(A,S). Symmetry of A makes A^{-1} symmetric, so the lower-left block cancels. Equivalently,
(x^T,y^T)M(x,y)^T=(x+A^{-1}By)^T A(x+A^{-1}By)+y^TSy.
This establishes the criterion by an invertible substitution, not an appeal to equal spectra.
