---
{
  "schema_version": "2.0.0",
  "id": "N-setting",
  "kind": "definition",
  "title": "Real symmetric blocks and positivity",
  "facets": [
    "foundations"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": []
}
---


# Real symmetric blocks and positivity

## Canonical statement

```latex
Let $m,n\geq1$, let $A\in\mathbb R^{m\times m}$ and $D\in\mathbb R^{n\times n}$ be symmetric, and let $B\in\mathbb R^{m\times n}$. Put $M=\begin{pmatrix}A&B\\B^\top&D\end{pmatrix}$. A real symmetric matrix $H$ is positive definite, written $H\succ0$, when $z^\top Hz>0$ for every nonzero real vector $z$ of the appropriate dimension. When $A$ is invertible, its Schur complement in $M$ is $S=D-B^\top A^{-1}B$.
```

## Explanation

Strict positivity tests every nonzero vector; semidefiniteness replaces > with >=. The transpose links the off-diagonal blocks, so this is a quadratic-form question.
