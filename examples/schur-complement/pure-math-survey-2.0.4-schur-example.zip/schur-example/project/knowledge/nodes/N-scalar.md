---
{
  "schema_version": "2.0.0",
  "id": "N-scalar",
  "kind": "example",
  "title": "A strict interval and its equality walls",
  "facets": [
    "foundations",
    "boundaries"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": [
    {
      "target": "N-criterion",
      "relation": "specializes"
    }
  ]
}
---


# A strict interval and its equality walls

For M_t=[[1,t],[t,1]], A=1 and S=1-t^2. Thus M_t>0 exactly for -1<t<1. At t=1, the form is (x+y)^2 and vanishes on (1,-1), so it is positive semidefinite but not positive definite. For |t|>1, the vector (-t,1) gives value 1-t^2<0. This example measures strictness instead of hiding it in notation.
