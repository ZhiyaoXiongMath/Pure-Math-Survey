---
{
  "schema_version": "2.0.0",
  "id": "N-determinant",
  "kind": "relation",
  "title": "Determinant consequence and its limits",
  "facets": [
    "results",
    "methods"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": [
    {
      "target": "N-setting",
      "relation": "uses_definition"
    },
    {
      "target": "N-factorization",
      "relation": "proof_input"
    }
  ]
}
---


# Determinant consequence and its limits

## Canonical statement

```latex
For symmetric real $A\in\mathbb R^{m\times m}$ and $D\in\mathbb R^{n\times n}$ and real $B\in\mathbb R^{m\times n}$, if $A$ is invertible then\[\det\begin{pmatrix}A&B\\B^\top&D\end{pmatrix}=\det(A)\det(D-B^\top A^{-1}B).\]
```

## Explanation

The block triangular P has determinant one, so taking determinants of the factorization gives the identity. Invertibility of M is equivalent to invertibility of S when A is invertible. Determinants alone do not test positive definiteness: diag(-1,-1) has positive determinant and negative quadratic form on each coordinate vector.
