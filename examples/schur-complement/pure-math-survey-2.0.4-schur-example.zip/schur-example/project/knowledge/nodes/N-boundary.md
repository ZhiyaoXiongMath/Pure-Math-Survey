---
{
  "schema_version": "2.0.0",
  "id": "N-boundary",
  "kind": "example",
  "title": "Singular pivots require a different statement",
  "facets": [
    "boundaries"
  ],
  "question_ids": [
    "N-question"
  ],
  "mathematical_status": "established",
  "origin": "local_derivation",
  "sources": [],
  "links": [
    {
      "target": "N-setting",
      "relation": "uses_definition"
    }
  ]
}
---


# Singular pivots require a different statement

The usual formula is undefined for singular A. A naive replacement by the pseudoinverse fails without additional hypotheses: A=0, B=1, D=1 has A>=0 and D-B^T A^dagger B=1, but (1,-1)^T M (1,-1)=-1. The off-diagonal coupling lies outside the range of A. The general range-condition theorem remains an explicitly omitted neighbor.

Congruence is not similarity: for M=[[2,1],[1,2]], the reduction is diag(2,3/2). The traces are 4 and 7/2, so these matrices cannot be similar. The correct positivity argument uses congruence.
