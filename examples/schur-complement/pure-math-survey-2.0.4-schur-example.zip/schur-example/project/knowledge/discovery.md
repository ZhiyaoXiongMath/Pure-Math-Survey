# Discovery and stopping decision

On 2026-09-28 searched: "Jean Gallier Schur complement symmetric positive definite matrices 2010 pdf".
Selected the author's University of Pennsylvania PDF, rather than search snippets
or redistribution sites. The institutional bitstream URL returned an HTML app
shell, not a PDF. The author URL returned a real 13-page PDF.

Search metadata suggested December 2010; the actual downloaded title page says
August 24, 2019. The latter is the controlling version. Read Sections 1--2,
printed pages 1--4, especially Proposition 2.2. Inspected Section 4's conclusion
and Theorem 4.3 on pages 12--13 for the omission challenge, not its full proof.

The page 3 factorization is a congruence, although nearby prose says "similar".
Our local formulation follows the verified equation and quadratic-form argument.
The general singular-pivot criterion requires a range condition; a concrete
counterexample is retained instead of claiming the inverse formula covers it.

Stopping reason: this bounded algebraic question has an exact criterion and a
complete direct proof from invertible block elimination. The source reading,
local calculation and explicit singular-pivot counterexample cover the stated
scope. This is not a comprehensive review of all Schur-complement applications.
