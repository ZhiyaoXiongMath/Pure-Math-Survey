# One quadratic form, two blocks

N-question asks for positive definiteness of a symmetric block matrix.
N-setting fixes dimensions and the quantifier in positive definiteness.
N-congruence justifies invertible substitutions; N-factorization performs the
elimination. Together they yield N-criterion, the principal answer.
N-determinant records a related consequence and its strictly weaker information.
N-scalar tests the criterion at both a strict point and an equality wall.
N-boundary identifies singular-pivot and similarity pitfalls.
N-generalized retains the neighboring pseudoinverse problem without importing
an unreviewed theorem into either output. These nodes span overlapping
foundations/results/methods/boundaries facets; they are not four manuscripts.
